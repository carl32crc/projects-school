<html>
<head> <title>Exercici 01</title></head>
<body>
	<h1> Generador de Formularios 1 </h1>
	<p>Escribe el número de controles que va contener el formularios:
	<form action="generador_formulario.php" method="post">
		Número de controles: <input type="text" name="numero">
		<input type="submit">
	</form>
</body>
</html>
