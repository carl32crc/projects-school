<html>
<head> <title>Exercici 01</title></head>
<body>
	<h1> Generador de &lt;select>(FORMULARIO 1) </h1>
	<p>Escribe el número de controles &lt;select> que va contener el formularios:
	<form action="generador_select.php" method="post">
		Número de selectores: <input type="text" name="selects">
      Número de opciones: <input type="text" name="opciones">
		<input type="submit">
	</form>
</body>
</html>
