<html>
<head> <title>Exercici 04</title></head>
<body>
	<h1> Casillas marcadas (FORMULARIO) </h1>
	<p>Escriba el número de filas y columnas y mostraré una tabla de casillas de verificación.
	<form action="generador_casillas.php" method="post">
		Número de filas: <input type="text" name="filas">
      Número de columnas: <input type="text" name="columnas">
		<input type="submit">
	</form>
</body>
</html>
