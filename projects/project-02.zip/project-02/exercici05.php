<html>
<head> <title>Exercici 05</title></head>
<body>
	<h1> Hotel (FORMULARIO 1) </h1>
	<p>Escriba el número de habitaciones del hotel(de 1 a 20).
	<form action="hotel_casillas.php" method="post">
		Número de habitaciones: <input type="text" name="habitaciones">
		<input type="submit">
	</form>
</body>
</html>
